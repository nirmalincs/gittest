from setuptools import setup,find_packages
setup(name='mysql1',version='1.0.0',description='my first app',author='nirmal',packages=find_packages())
